import Imap from "imap";
import { simpleParser } from "mailparser";
import { inspect } from "util";

// for web mail
// user: "alam@wooxperto.com",
// password: "1OG2f%qWesuH%1!i",

export const fetchEmailsUsingImap = (req, res, next) => {
  const imap = new Imap({
    user: "dev.alam@yahoo.com",
    password: "wooxperto321@#",
    host: "imap.mail.yahoo.com",
    port: 993, // IMAP over SSL port
    tls: true,
  });

  const emails = [];

  function openInbox(cb) {
    imap.openBox("INBOX", false, cb);
  }

  imap.connect();

  imap.once("ready", () => {
    openInbox((err, box) => {
      if (err) {
        return res.status(500).json({
          status: false,
          message: "Failed to open inbox",
          error: err.message,
        });
      }
      const searchCriteria = ["UNSEEN"]; // Fetch unread emails
      const fetchOptions = {
        bodies: "", // Fetch the entire message (headers, body, etc.)
        struct: true,
        markSeen: false,
      };

      imap.search(searchCriteria, (err, results) => {
        if (err) {
          return res.status(500).json({
            status: false,
            message: "Error searching emails",
            error: err.message,
          });
        }
        if (!results.length) {
          imap.end();
          return res.status(200).json({
            status: true,
            message: "No new emails found",
            data: [],
          });
        }
        const fetch = imap.fetch(results, fetchOptions);

        fetch.on("message", (msg, seqno) => {
          const prefix = "(#" + seqno + ") ";

          let emailData = {};
          msg.on("body", (stream, info) => {
            let buffer = "";
            stream.on("data", (chunk) => (buffer += chunk.toString("utf8")));
            stream.once("end", () => {
              simpleParser(buffer, (err, parsed) => {
                if (err) {
                  console.error(prefix + "Error parsing email: ", err);
                } else {
                  emailData.header = parsed.headers; // Save headers
                  emailData.subject = parsed.subject; // Save subject
                  emailData.from = parsed.from.text; // Save sender
                  emailData.to = parsed.to.text; // Save recipient
                  emailData.text = parsed.text; // Save plain text content
                  emailData.html = parsed.html; // Save HTML content (if any)
                }
              });
            });
          });

          msg.once("attributes", (attrs) => {
            emailData.attrs = attrs;
          });

          msg.once("end", () => {
            emails.push(emailData);
          });
        });

        fetch.once("error", (err) => {
          console.log("Fetch error: " + err);
        });

        fetch.once("end", () => {
          imap.end();
          return res.status(200).json({
            status: true,
            message: "Emails fetched successfully",
            data: emails,
          });
        });
      });
    });
  });

  imap.once("error", (err) => {
    return res.status(500).json({
      status: false,
      message: "Connection error",
      error: err.message,
    });
  });

  imap.once("end", () => {
    console.log("Connection ended");
  });
};
